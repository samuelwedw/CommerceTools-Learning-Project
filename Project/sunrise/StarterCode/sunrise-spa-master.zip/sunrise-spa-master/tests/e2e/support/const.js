export default {
  one: {
    PRICE: '137,50',
    OLD_PRICE: '275,00',
    NAME: 'Sneakers ”R261” Hogan Rebel grey',
    sku: 'M0E20000000DX1Y',
  },
  two: {
    NAME: 'Flip Flops “Brasil“ Havaianas green',
  },
  three: {
    PRICE: '24,00',
    NAME: 'Flip Flops “Brasil“ Havaianas grey',
  },
};
