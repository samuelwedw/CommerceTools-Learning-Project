<template src="./template.html"></template>
<script src="./script.js"></script>
<i18n src="./i18n.txt"></i18n>
