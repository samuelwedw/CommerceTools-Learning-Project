<template src="./template.html"></template>
<style src="./style.scss" lang="scss" scoped></style>
<script src="./script.js"></script>
