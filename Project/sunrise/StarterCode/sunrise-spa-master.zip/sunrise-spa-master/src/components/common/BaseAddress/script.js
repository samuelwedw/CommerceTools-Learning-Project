export default {
  props: {
    address: {
      type: Object,
      required: true,
    },
  },
};
