<template src="./template.html"></template>
<style src="./style.css" scoped></style>
<script src="./script.js"></script>
