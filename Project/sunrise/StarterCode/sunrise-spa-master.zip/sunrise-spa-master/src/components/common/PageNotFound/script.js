export default {
  name: 'NotFoundPage',
};
