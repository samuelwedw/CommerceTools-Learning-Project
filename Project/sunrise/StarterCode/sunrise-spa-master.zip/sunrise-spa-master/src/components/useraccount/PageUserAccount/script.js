import SidebarMenu from '../SidebarMenu/index.vue';

export default {
  components: { SidebarMenu },
};
