import authMixin from '../../../mixins/authMixin';

export default {
  mixins: [authMixin],
};
