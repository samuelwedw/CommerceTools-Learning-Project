<template src="./template.html"></template>
<i18n src="./i18n.txt"></i18n>
<script src="./script.js"></script>
