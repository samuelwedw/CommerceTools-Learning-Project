import LoginForm from '../LoginForm/index.vue';
import SignUpForm from '../SignUpForm/index.vue';

export default {
  components: {
    LoginForm,
    SignUpForm,
  },
};
