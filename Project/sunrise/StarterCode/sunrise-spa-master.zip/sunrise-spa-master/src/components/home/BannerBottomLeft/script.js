import BannerPicture from '../BannerPicture/index.vue';

export default {
  components: { BannerPicture },
};
