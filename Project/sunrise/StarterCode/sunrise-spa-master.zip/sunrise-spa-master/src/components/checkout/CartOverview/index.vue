<template src="./template.html"></template>
<style src="./style.scss" lang="scss" scoped></style>
<i18n src="./i18n.txt"></i18n>
<script src="./script.js"></script>
