import CartOverview from '../CartOverview/index.vue';

export default {
  components: { CartOverview },
};
