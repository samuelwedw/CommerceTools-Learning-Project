import CheckoutTitle from '../CheckoutTitle/index.vue';

export default {
  components: {
    CheckoutTitle,
  },
};
