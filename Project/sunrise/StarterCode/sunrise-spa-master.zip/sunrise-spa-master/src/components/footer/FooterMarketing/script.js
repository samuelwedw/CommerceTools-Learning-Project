import NewsletterSubscriptionForm from '../NewsletterSubscriptionForm/index.vue';

export default {
  components: { NewsletterSubscriptionForm },
};
