import BaseFooter from '../BaseFooter/index.vue';

export default {
  components: {
    BaseFooter,
  },
};
