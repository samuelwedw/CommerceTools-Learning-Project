Until new content is defined, you can check [Sunrise Java's guidelines](https://github.com/commercetools/commercetools-sunrise-java/blob/master/CONTRIBUTING.md).
